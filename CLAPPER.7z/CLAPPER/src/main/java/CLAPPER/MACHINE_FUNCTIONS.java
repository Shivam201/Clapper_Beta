package CLAPPER;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import com.jcraft.jsch.*;

public class MACHINE_FUNCTIONS {
	
	/**
	 * 
	 * @param HOST - localhost
	 * @param USERNAME - test
	 * @param PASSWORD	- test
	 * @param COMMAND	- LINUX -  "top"
	 *  	  COMMAND	- WINDOWS -  "wmic OS get FreePhysicalMemory,FreeVirtualMemory,FreeSpaceInPagingFiles /VALUE"
	 * @return
	 */
	public String MACHINE_CONNECT_RUNCOMMAND(String HOST, String USERNAME, String PASSWORD,String COMMAND)
	{
		String host = HOST;
        String user = USERNAME;
        String password = PASSWORD;
        String command = COMMAND;
        String RESPONSE = "";
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(user,host, 22);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword(password);
            //session.setTimeout(10000); // ten second timeout //
            session.connect();
            System.out.println("Machine Connected");
            
            Channel channel = session.openChannel("exec");
            channel.setInputStream(new ByteArrayInputStream(command.getBytes(StandardCharsets.UTF_8)));
            channel.setOutputStream(System.out);
            InputStream in = channel.getInputStream();
            StringBuilder outBuff = new StringBuilder();
            int exitStatus = -1;
            
            channel.connect();
            
            while (true) {                
                for (int c; ((c = in.read()) >= 0);) {
                    outBuff.append((char) c);
                }
                
                if (channel.isClosed()) {
                    if (in.available() > 0) continue;
                    exitStatus = channel.getExitStatus();
                    break;
                }
            }
            channel.disconnect();
            session.disconnect();
            System.out.print (outBuff.toString());
	        RESPONSE = "SUCCESS - "+outBuff.toString(); 
                
        } 
        catch (IOException | JSchException ioEx) {
        	RESPONSE = "UNSUCCESS - "+ioEx.toString();
        	System.err.println(ioEx.toString());
        }
        
        return RESPONSE;
    }   
	
	/**
	 * Function for checking Machine is reachable or not
	 * @param HOST
	 * @param USERNAME
	 * @param PASSWORD
	 * @return
	 */
	public String MACHINE_CONNECT(String HOST, String USERNAME, String PASSWORD)
	{
		String host = HOST;
        String user = USERNAME;
        String password = PASSWORD;
        String RESPONSE = "";
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(user,host, 22);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword(password);
            //session.setTimeout(10000); // ten second timeout //
            session.connect();
            System.out.println("Machine Connected");
            session.disconnect();
            RESPONSE = "SUCCESS - Machine Connected"; 
        } 
        catch (Exception e) {
        	RESPONSE = "UNSUCCESS - Machine not able to Connect";
        }        
        return RESPONSE;
    }
}
