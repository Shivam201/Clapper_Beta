package CLAPPER;

/**
 * Hello world!
 *
 */
public class Driver 
{
    public static void main( String[] args )
    {
//        System.out.println( "Hello World!" );
//        String url = "jdbc:mysql://localhost:3306/";
//        String dbName = "";
//        String username = "root";
//        String password = "root";
//        DATABASE_FUNCTIONS obj = new DATABASE_FUNCTIONS();
//        System.out.println(obj.connectMysql(url, username,""));
    	
    	
    	
    }
}
