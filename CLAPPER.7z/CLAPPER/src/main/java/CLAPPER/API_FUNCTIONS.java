package CLAPPER;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import io.restassured.RestAssured;
import io.restassured.response.Response;


public class API_FUNCTIONS {
	public static void main(String args[]) throws MalformedURLException, IOException, ParseException, NoSuchAlgorithmException
	{
		
		//System.out.println(URLCHECK("http://localhost:3000/wines123321"));
		//System.out.println(URLCHECK("http://dummy.restapiexample.com/api/v1/employees"));
		//System.out.println(URLCHECK("https://www.google.com/search?q=ShivamMaralay"));
		//System.out.println(URLCHECK("https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png"));
		// Jira
		System.out.println(URLCHECK("z"));
		System.out.println(URLCHECK("https://dreamtechsolution.atlassian.net/secure/RapidBoard.jspa?projectKey=JIRA&rapidView=1"));
		//
		//System.out.println(URLCHECK("https://dreamtechsolution.atlassian.net"));
		//System.out.println(URLCHECK("https://jira.sp.vodafone.com/tempcps/rest/auth/1/session"));
		//System.out.println(URLCHECK("https://dreamtechsolution.atlassian.net/rest/auth/1/session"));
		
		// Confluence
		//System.out.println(URLCHECK("https://confluence.atlassian.com/display/CONF52"));
		//System.out.println(URLCHECK("https://confluence.atlassian.com/display/CONF52"));
		
		String APIJSON = ReadConfigFile("GOOGLESEARCH_PARAMETER");
		//String APIJSON = ReadConfigFile("GET_PARAMETER");
		GetMethod(APIJSON);
	}
	
	/**
	 * Function for getting the status code for URL
	 * @param URL
	 * @return
	 */
	public static String URLCHECK(String URL)
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));  
		System.out.println("******** Checking For "+URL+" **********");
		String RESPONSE = "";
		String response = "";
		int responseCode = 0;
		//String cookie = "atlassian.xsrf.token=1e2cd753-1678-4f4d-ba70-e1a0c9480041_2dce08cdcfb9b8299892d16991fea06470b408d2_lout";
		try {
			HttpURLConnection connection = (HttpURLConnection) new URL(URL).openConnection();
			connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
			connection.setRequestMethod("GET");
			responseCode = connection.getResponseCode();
			response=connection.getResponseMessage() ;			
			dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
			now = LocalDateTime.now();  
			System.out.println(dtf.format(now));
			RESPONSE = "SUCCESS - RESPONSECODE:"+responseCode+" RESPONSEMESSAGE:"+response.trim();
		}
		catch(Exception e)
		{
			//System.out.println("Exception "+e);
			RESPONSE = ("UNSUCCESS - with Exception = "+e);
			
		}
		return RESPONSE;
	}
		
	/**
	 * GET Method call for Rest Assured
	 * @param BASEPATH
	 * @param RESOURCEPATH
	 * @param PROXYIP
	 * @param PORT
	 * @param QUERYPARAM
	 * @param FORMPARAM
	 * @param HEADERPARAM
	 * @return
	 * @throws ParseException 
	 * @throws NoSuchAlgorithmException 
	 */
	public static String GetMethod(String APIJSON) throws ParseException, NoSuchAlgorithmException
	{
		String BASEPATH = GET_BASEPATH(APIJSON);
		String RESOURCEPATH = GET_RESOURCEPATH(APIJSON);;
		String PROXYIP = GET_PROXYIP(APIJSON);
		String PORT = GET_PORT(APIJSON);		
		HashMap<String,String> QUERYPARAM = GET_QUERYPARAMETER(APIJSON);
		HashMap<String, String> HEADERPARAM = GET_HEADERPARAMETER(APIJSON);
		
		String RESPONSE = "";
		int StatusCode = 0;
		String ResponseDescription = "";
		Response response = null;
		
		// BASEPATH CHECK //
			if(BASEPATH.length()<5)
				return "FAILURE : BASEURL is blank,Kindly check and retry";
			
			RestAssured.baseURI =BASEPATH;
		
		// PROXYIP and PORT Check //	
			if(PROXYIP.length()>2 && PORT.length()>1)
				RestAssured.proxy(PROXYIP,Integer.parseInt(PORT));
			else
				System.out.println("** No Proxy IP and PORT Found so proceeding without That **");
		
		try 	
		{				
			// Checking Query Parameter Since this is GET call and FORMPARAMETER cannot be used //
				if(QUERYPARAM.size()>0 && HEADERPARAM.size()>0) 
				{
					System.out.println("Requesting GET with Header and Query Parameter");
					System.out.println(HEADERPARAM.size());
					String URI = BASEPATH+RESOURCEPATH;
					System.out.println(URI);
					response = RestAssured.given()
										  .when()
										  .headers(HEADERPARAM)
										  .queryParameters(QUERYPARAM)
										  .get(BASEPATH+RESOURCEPATH); 
				}
				
			// Checking if Both Query Parameter and Header Parameter is blank //
				if(QUERYPARAM.size()==0 && HEADERPARAM.size()==0) 
				{
					System.out.println("Requesting GET with No Header and Query Parameter");
					response = RestAssured.given()
										  .when()
										  .get(BASEPATH+RESOURCEPATH); 
				}
				
			// Checking if Query Parameter is blank and not Header Parameter //
				if(QUERYPARAM.size()==0 && HEADERPARAM.size()>0) 
				{
					System.out.println("Requesting GET with Header But No Query Parameter");
					response = RestAssured.given()
										  .when()
										  .headers(HEADERPARAM)
										  .get(BASEPATH+RESOURCEPATH); 
				}	
				
			// Checking if Header Parameter is blank not query Parameter//
				if(QUERYPARAM.size()>0 && HEADERPARAM.size()==0) 
				{
					System.out.println("Requesting GET with No Header But Query Parameter");
					response = RestAssured.given().relaxedHTTPSValidation()
										  .when()
										  .queryParameters(QUERYPARAM)
										  .get(BASEPATH+RESOURCEPATH); 
				}	
			
			// Taking the Status Code and Response Description//
				System.out.println("Response :" + response.asString());
				System.out.println("Status Code:" + response.getStatusCode()); 
				StatusCode = response.getStatusCode();
				ResponseDescription = response.asString();
				RESPONSE = "SUCCESS - RESPONSECODE:"+StatusCode+" RESPONSEMESSAGE:"+ResponseDescription.trim();
		}
		catch(Exception e)
		{
			RESPONSE = "UNSUCCESS - with Exception = "+e;
		}
		return RESPONSE;
}	
	
	/**
	 * Reading BasePath from API - JSON
	 * @param APIJSON
	 * @return
	 * @throws ParseException
	 */
	public static String GET_BASEPATH(String APIJSON) throws ParseException {
		String BASEPATH = "";
		try 
		{
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(APIJSON);
			JSONObject jsonobj = (JSONObject)obj;
			BASEPATH = (String) jsonobj.get("BASEURL");
		}
		catch(ParseException parse)
		{
			System.out.println("Issue in parsing JSON please check and try again");
		}
		return BASEPATH;
	}
	
	/**
	 * Return ResourceURL which will add in BASEURL to form Complete URL
	 * @param APIJSON
	 * @return
	 * @throws ParseException
	 */
	public static String GET_RESOURCEPATH(String APIJSON) throws ParseException {
		String RESOURCEPATH = "";
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(APIJSON);
		JSONObject jsonobj = (JSONObject)obj;
		RESOURCEPATH = (String) jsonobj.get("RESOURCEURL");
		return RESOURCEPATH;
	}
	
	/**
	 * Return Proxy IP - if required to use
	 * @param APIJSON
	 * @return
	 * @throws ParseException
	 */
	public static String GET_PROXYIP(String APIJSON) throws ParseException {
		String PROXYIP = "";
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(APIJSON);
		JSONObject jsonobj = (JSONObject)obj;
		PROXYIP = (String) jsonobj.get("PROXYIP");
		return PROXYIP;
	}
	
	/**
	 * Read PAYLOAD
	 * @param APIJSON
	 * @return
	 * @throws ParseException
	 */
	public static String READ_PAYLOAD(String APIJSON) throws ParseException {
		String PAYLOADFILENAME = "";
		String PAYLOAD = "";
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(APIJSON);
		JSONObject jsonobj = (JSONObject)obj;
		PAYLOADFILENAME = (String) jsonobj.get("PAYLOADFILE");
		
		if(!PAYLOADFILENAME.toLowerCase().contains(".json"))
			PAYLOADFILENAME = PAYLOADFILENAME+".json";
		
		String CurrentDir = "";
		String OS = System.getProperty("os.name");
		if(OS.toLowerCase().contains("window"))
			CurrentDir = System.getProperty("user.dir")+"\\config\\JSONFILES\\"+PAYLOADFILENAME;
		else
			CurrentDir = System.getProperty("user.dir")+"/config/JSONFILES/"+PAYLOADFILENAME;
		
		File PayloadFile = new File(CurrentDir);
		PAYLOAD = ReadJSON(PayloadFile);		
		return PAYLOAD;
	}
	
	/**
	 * Return Proxy PORT - if required to use
	 * @param APIJSON
	 * @return String
	 * @throws ParseException
	 */
	public static String GET_PORT(String APIJSON) throws ParseException {
		String PORT = "";
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(APIJSON);
		JSONObject jsonobj = (JSONObject)obj;
		PORT = (String) jsonobj.get("PORT");
		return PORT;
	}
	
	/**
	 * Return all the Query Parameter from APIJSON
	 * @param APIJSON
	 * @return HASHMAP
	 * @throws ParseException
	 */
	public static HashMap<String,String> GET_QUERYPARAMETER(String APIJSON) throws ParseException {
		HashMap<String, String> QUERYPARAM = new HashMap<String, String>();
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(APIJSON);
		JSONObject jsonobj = (JSONObject)obj;
		JSONObject queryobj = (JSONObject) jsonobj.get("QUERYPARAM");
		Set<String> AllKey = queryobj.keySet();
		for (String Key : AllKey) {
			String Value = (String) queryobj.get(Key);
			//System.out.println("Key="+Key);
			//System.out.println("Value="+Value);
			if(Key.length()>0)
				QUERYPARAM.put(Key,Value.trim());
		}
		return QUERYPARAM;
	}
	
	/**
	 * Return all the form Parameter from API JSON
	 * @param APIJSON
	 * @return
	 * @throws ParseException
	 */
	public static HashMap<String,String> GET_FORMPARAMETER(String APIJSON) throws ParseException {
		HashMap<String, String> FORMPARAM = new HashMap<String, String>();
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(APIJSON);
		JSONObject jsonobj = (JSONObject)obj;
		JSONObject queryobj = (JSONObject) jsonobj.get("FORMPARAM");
		Set<String> AllKey = queryobj.keySet();
		for (String Key : AllKey) {
			String Value = (String) queryobj.get(Key);
			//System.out.println("Key="+Key);
			//System.out.println("Value="+Value);
			if(Key.length()>0)
				FORMPARAM.put(Key,Value.trim());
		}
		return FORMPARAM;
	}	

	/**
	 * Return All the Header Parameter from API JSON 
	 * @param APIJSON
	 * @return
	 * @throws ParseException
	 */
	public static HashMap<String,String> GET_HEADERPARAMETER(String APIJSON) throws ParseException {
		HashMap<String, String> HEADERPARAM = new HashMap<String, String>();
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(APIJSON);
		JSONObject jsonobj = (JSONObject)obj;
		JSONObject queryobj = (JSONObject) jsonobj.get("HEADERPARAM");
		Set<String> AllKey = queryobj.keySet();
		for (String Key : AllKey) {
			String Value = (String) queryobj.get(Key);
			//System.out.println("Key="+Key);
			//System.out.println("Value="+Value);
			if(Key.length()>0)
				HEADERPARAM.put(Key,Value.trim());
		}
		return HEADERPARAM;
	}
	
	public static String ReadJSON(File F)
	{
		 JSONParser jsonParser = new JSONParser();
         String Value = "";
	        try (FileReader reader = new FileReader(F))
	        {
	            //Read JSON file
	            Object obj = jsonParser.parse(reader);
	            
	            Value = obj.toString();
	        }
	        catch(Exception e)
	        {
	        	System.out.println("");
	        }
	            return Value;
		
	
	}
	
	
	/**
	 * Read Specific Key from Mentioned ConfigFile
	 * @author SHIVAM 
	 * @param ConfigFile
	 * @param Key
	 * @return Value
	 * @throws IOException
	 */
	public static String ReadConfigFile(String Key) throws IOException
	{
		String Value = "";
		String ENV_SETUP_CONFIG_FILE = "apiconfig.properties";
		
		String APICONFIG_FILE = "";		
		Properties prop = new Properties();
		
		String OS = System.getProperty("os.name");
		if(OS.toLowerCase().contains("window"))
			ENV_SETUP_CONFIG_FILE = System.getProperty("user.dir")+"\\ConfigurationSettings\\"+ENV_SETUP_CONFIG_FILE;
		else
			ENV_SETUP_CONFIG_FILE = System.getProperty("user.dir")+"/ConfigurationSettings/"+ENV_SETUP_CONFIG_FILE;
		
		// Property File Name updated as per Environment File //
		try 
		{
			prop.load(new FileInputStream(ENV_SETUP_CONFIG_FILE));	
			Value = prop.getProperty(Key);
		}
		catch(Exception e)
		{
			System.out.println("Exception in reading config File "+e);
		}
		
		return Value;
	}

	
}