package CLAPPER;

import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Collections;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.azure.cosmos.ConsistencyLevel;
import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
public class DATABASE_FUNCTIONS {
	
	/**
	 * 
	 * @param HOSTURL = "jdbc:mysql://localhost:3306/"
	 * @param USERNAME = "root"
	 * @param PASSWORD = "root"
	 * @return
	 */
	public String connectMysql(String HOSTURL,String USERNAME,String PASSWORD)
	{
		if(HOSTURL.length()==0 || USERNAME.length()==0)
			return "UNSUCCESS : HOSTNAME/USERNAME are mandatory";
		
		else
		{
			String StatusMessage = "";
			
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection(  
				HOSTURL,USERNAME,PASSWORD);  
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("show databases");  
				StatusMessage = "SUCCESS";
				while(rs.next())
				{
					System.out.println(rs.getRow());
				}
				con.close();  
			}catch(Exception e){ 
				StatusMessage = "UNSUCCESS = "+e;
			}  
			return StatusMessage;
		}	
	}
	
	/**
	 * @param HOSTURL = "jdbc:oracle:thin:@localhost:1521:xe"
	 * @param USERNAME = "system"
	 * @param PASSWORD = "oracle"
	 * @return
	 */
	public String connectOracle(String HOSTURL,String USERNAME,String PASSWORD)
	{
		if(HOSTURL.length()==0 || USERNAME.length()==0)
			return "UNSUCCESS : HOSTNAME/USERNAME are mandatory";
		
		else
		{
			String StatusMessage = "";
			try{  
				Class.forName("oracle.jdbc.driver.OracleDriver");  
				Connection con=DriverManager.getConnection(  
				HOSTURL,USERNAME,PASSWORD);  
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("select * from v$database");  
				StatusMessage = "SUCCESS";
				while(rs.next())
				{
					System.out.println(rs.getRow());
				}
				con.close();  
				
				}catch(Exception e){ 
					StatusMessage = "UNSUCCESS = "+e;
				}  
				return StatusMessage;
		}	
	} 
	
	/**
	 * @param HOSTURL = "localhost:27017"
	 * @param USERNAME = "user"
	 * @param PASSWORD = "password"
	 * @return
	 * @throws UnknownHostException 
	 */
	public String connectMongodb(String HOSTURL,String USERNAME,String PASSWORD)
	{
		String StatusMessage = "";
		if(HOSTURL.length()==0 || USERNAME.length()==0 || PASSWORD.length()==0)
			return "UNSUCCESS - HOSTURL / USERNAME / PASSWORD is mandatory";
		
		else
		{	
			String URI = "mongodb://"+USERNAME+":"+PASSWORD+"@"+HOSTURL+"/?authSource=test";
			MongoClientURI uri = new MongoClientURI(URI);
			try 
			{
				MongoClient mongoClient = new MongoClient(uri);
				if(mongoClient.getDatabaseNames().size()>=0)
					StatusMessage="SUCCESS";
			}
			catch(Exception e)
			{
				StatusMessage="UNSUCCESS"+e;
			}
			return StatusMessage;
		}
	}
		
	/**
	 * @param serverIP = 127.0.0.1 
	 * @param keyspace = databases
	 * @return 
	 */
	public String connectCassandra(String serverIP,String keyspace)
	{
		String StatusMessage = "";
		if(serverIP.length()==0 || keyspace.length()==0)	
			return "UNSUCCESS - serverIP/keyspace is mandatory";
		
		else
		{
			Cluster cluster = Cluster.builder().addContactPoints(serverIP).build();
			Session session = cluster.connect(keyspace);
			try 
			{
				String cqlStatement = "SELECT * FROM system_schema.keyspaces";
				for (Row row : session.execute(cqlStatement)) {
				  //System.out.println(row.toString());
				}
				StatusMessage = "SUCCESS";
			}
			catch(Exception e)
			{
				StatusMessage = "UNSUCCESS"+e;
			}
			return StatusMessage;
		}			
	}
	
	/**
	 * @param HOSTURL = "jdbc:postgresql://localhost:5432/"
	 * @param DBNAME = "example"
	 * @param USERNAME = "user"
	 * @param PASSWORD = "password"
	 * @return
	 * @throws UnknownHostException 
	 */
	public String connectPostgress(String HOSTURL,String DBNAME , String USERNAME,String PASSWORD)
	{
		String StatusMessage = "";
		if(HOSTURL.length()==0 ||DBNAME.length()==0||USERNAME.length()==0|| PASSWORD.length()==0)
			return "UNSUCCESS - HOSTURL/DBNAME/USERNAME/PASSWORD is mandatory";
		
		else
		{
			String URI = "jdbc:postgresql://"+USERNAME+":"+PASSWORD+"/"+DBNAME+"";
			try 
			{
				Class.forName("org.postgresql.Driver"); 
				Connection connection = DriverManager.getConnection(URI, "postgres", "postgres"); 
	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery("\\dt");
	            while (resultSet.next()) {
	            } 
	            StatusMessage= "SUCCESS";
	        }catch (Exception e) {
	        	StatusMessage= "UNSUCCESS"+e;
	        }
		}		
		return StatusMessage;	
	}
	
	/**
	 * @param HOSTURL = "https://docdb-java-sample.documents.azure.com:443/"
	 * @param MASTER_KEY = "SampleMasterKey"
	 * @return
	 * @throws UnknownHostException 
	 */
	public String connectCosmosdb(String HOSTURL,String MASTER_KEY)
	{
		String StatusMessage = "";
		CosmosClient client;

	    if(HOSTURL.length()==0 || MASTER_KEY.length()==0)
	    	return "UNSUCCESS HOSTURL/MASTERKEY is mandatory";
	    
	    else
	    {	
		    try {
		       	    client = new CosmosClientBuilder()
		            .endpoint(HOSTURL)
		            .key(MASTER_KEY)
		            //  Setting the preferred location to Cosmos DB Account region
		            //  West US is just an example. User should set preferred location to the Cosmos DB region closest to the application
		            .preferredRegions(Collections.singletonList("West US"))
		            .consistencyLevel(ConsistencyLevel.EVENTUAL)
		            .buildClient();
		       	    StatusMessage = "SUCCESS";
		    }
		    catch(Exception e)
		    {
		    	StatusMessage = "UNSUCCESS -"+e;
		    }
		    return StatusMessage;
	    }   	    
	   	
	}
	
}
