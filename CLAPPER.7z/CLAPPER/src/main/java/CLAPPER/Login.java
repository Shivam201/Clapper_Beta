package CLAPPER;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author SHIVAM
 */
public class Login extends Application{
                    public static void main(String[] args) {
                        launch(args);
                    }

                    @Override
                    public void start(final Stage primaryStage) throws InterruptedException {
                        /**
                         * Page 1 - Title = CLAPPER at TOP , No Maximization possible
                         * Adding New Image as Icon
                        */
                    	
                    	primaryStage.setTitle("CLAPPER - SingleMonitoringSystem");
                        primaryStage.setResizable(false);
                        primaryStage.getIcons().add(new Image("file:C:\\Users\\Shivam\\Documents\\NetBeansProjects\\CLAPPER_Beta1\\src\\clapper\\Icon.png"));

                        /**
                         * Initializing GRID -- 
                         */     
                        final GridPane grid = new GridPane();
                        grid.setAlignment(Pos.CENTER);
                        grid.setHgap(10);
                        grid.setVgap(10);
                        grid.setPadding(new Insets(25, 25, 25, 25));

                        BorderPane border = new BorderPane();
                        
                        /**
                         * Defining Components 
                         */

                                // -- LABEL USERNAME-- //
                        Label userName = new Label("Username:");
                        userName.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
                        userName.setTextFill(Color.FORESTGREEN);
                        grid.add(userName, 0, 0);

                        TextField userTextField = new TextField();
                        grid.add(userTextField, 1, 0);



                                // -- LABEL PASSWORD-- //
                        Label passWord = new Label("Password:");
                        passWord.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
                        passWord.setTextFill(Color.FORESTGREEN);
                        grid.add(passWord, 0, 1);


                        final PasswordField passWordField = new PasswordField();
                        passWordField.setText("");
                        grid.add(passWordField, 1, 1);


                                // -- SignIn Button -- //
                        Button btn = new Button("Sign in");
                        HBox hbBtn = new HBox(10);
                        hbBtn.setAlignment(Pos.BOTTOM_LEFT);
                        hbBtn.getChildren().add(btn);
                        grid.add(hbBtn, 2, 2);

                                // -- Adding Action for Sign In -- //
                        final Text actiontarget = new Text();
                        actiontarget.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));


                        btn.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent e) {
                                // If object added in same place error will come so removing the item //
                                grid.getChildren().remove(actiontarget);
                                String password = passWordField.getText();
                                if(password.equals("1234"))
                                 {   
                                     grid.add(actiontarget, 1, 2);
                                     actiontarget.setFill(Color.CHARTREUSE);
                                     actiontarget.setText("Login Success");

                                     // -- Continue Button -- //
                                     Button btn = new Button("Continue");
                                     HBox hbBtn = new HBox(10);
                                     hbBtn.getChildren().add(btn);
                                     grid.add(hbBtn, 1, 3);
                                     btn.setOnAction(new EventHandler<ActionEvent>() {
                                        @Override
                                        public void handle(ActionEvent e) {
                                            // -- Going to DRIVE Page -- //
                                            
                                            //CREATE_REPORTING obj2 = new CREATE_REPORTING();
//                                            try {
//                                                obj2.CreateHTML(17, 10, 5, 2,10);
//                                            } catch (IOException ex) {
//                                                Logger.getLogger(HomePage.class.getName()).log(Level.SEVERE, null, ex);
//                                            }
                                                                                       
                                            primaryStage.close();
                                            //CLAPPER_DRIVER obj = new CLAPPER_DRIVER();
//                                            try {
//                                                obj.start(primaryStage);
//                                            } catch (InterruptedException ex) {
//                                                Logger.getLogger(HomePage.class.getName()).log(Level.SEVERE, null, ex);
//                                            }
                                        }
                                    });          
                                 }
                                else
                                 {  
                                    grid.add(actiontarget, 1, 2); 
                                    actiontarget.setFill(Color.FIREBRICK);
                                    actiontarget.setText("Login Failure");
                                 }
                            }
                        });
                                // -- Welcome Username -- //
                        //Text scenetitle = new Text("Welcome "+System.getProperty("user.name"));
//                        scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
//                        scenetitle.setFill(Color.AZURE);
//                        grid.add(scenetitle, 0, 3, 2, 1);

                        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
                        int height = (int) screenBounds.getHeight();
                        int width = (int) screenBounds.getWidth();
                        //System.out.println(screenBounds.getWidth());
                        
                        Scene scene = new Scene(grid, width/3 , height/2.5);
                        grid.setBackground(Background.EMPTY);
                        
                        String style = "-fx-background-color: #2f4f4f;";
                        grid.setStyle(style);
                        border.setStyle(style);
                        primaryStage.setScene(new Scene(border, 900, 640));
                        primaryStage.setResizable(false);
                        
                        primaryStage.show();
                        primaryStage.setScene(scene);
                        primaryStage.show();
                    }  
}