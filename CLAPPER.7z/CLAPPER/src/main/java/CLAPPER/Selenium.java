package CLAPPER;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Selenium {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver","F:\\Java Project Repository\\jar\\chromedriver_win32_84\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver","F:\\Java Project Repository\\jar\\chromedriver_win32\\chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		
		
		options.addArguments("headless");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://dreamtechsolution.atlassian.net/secure/RapidBoard.jspa?projectKey=JIRA&rapidView=1");
		//Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, 20);
		WebElement Username = wait.until(ExpectedConditions.elementToBeClickable(By.id("username")));
				Username.sendKeys("shivam201@gmail.com");
		//driver.findElement(By.xpath("//*[@id=\"login-submit\"]/span/span")).click();
		driver.findElement(By.xpath("//*[contains(@id,'login-submit')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("9871820627");
		driver.findElement(By.xpath("//*[contains(@id,'login-submit')]")).click();
		
		
		
		Thread.sleep(10000);
		
		System.out.println("URL = "+driver.getCurrentUrl());
		System.out.println("Source = "+driver.getPageSource());
	}
	
	
	
	
	
	//https://dreamtechsolution.atlassian.net/secure/RapidBoard.jspa?projectKey=JIRA&rapidView=1
	// id = username	By.
	// span = Continue  By.xpath("span[text()='Continue']")
	// id = password
	// span = Log in = By.xpath("span[text()='Log in']")
	

}
