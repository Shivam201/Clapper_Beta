Agenda behind Clapper
Every Company have there own set of handling different components while developing any web,desktop, service based application.
For checking that it is up 24/7*365 they develop or buy Monitoring
1. for different components there will be different monitoring
2. No tool will check the JIRA / Confluence and other pages which direct affect the productivity.

So CLAPPER is designed 
1. It will handle all these component and status wull be seen at 1 page html show page.
2. It will generate report per day basis and will tell - how much time system was available.
3. There will be alert via mail to the person responsible [future version it will be extended to sms notification]
4. with clapper UI you will be allowed to use how many thread you wish to be used for monitoring otherwise it will suggest what is best to use.
5. you can schedule the running mode.

Pre-Requisite
1. Java 1.8 or higher version is required.
2. CLAPPER should be placed in the machine from where all the Components are direct reachable else it wont be able to monitor them properly.
	-   At any point if there is proxy please enter the proxy IP / PORT.
	-   If any Customization is required kindly reach to the helpdesk@clapper.com or call us @+91-9871820627

 
		


